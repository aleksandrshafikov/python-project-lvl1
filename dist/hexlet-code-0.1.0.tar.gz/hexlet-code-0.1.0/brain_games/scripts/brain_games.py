from cli import welcome_user


def greet():
    print("Welcome to the Brain Games!")


greet()



welcome_user()

def main():
    None


if __name__=='__main__':
    main()
